import numpy as np
import cv2
import skimage
import scipy
import time
import matplotlib as mlp

np.set_printoptions(suppress=True)

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# TODO your implementation

