import numpy as np
import cv2
import skimage
import matplotlib
import math

np.set_printoptions(suppress=True)

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# TODO your implementation

